import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:logger/logger.dart';
import 'dart:math' as math;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(BMIRecordAdapter());
  await Hive.openBox<BMIRecord>('bmiHistory');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BMI Voice by dr. Sapto',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        scaffoldBackgroundColor: Colors.grey[50],
        textTheme: TextTheme(
          titleLarge: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.purple[800],
          ),
          bodyLarge: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w500,
            color: Colors.purple[700],
          ),
          bodyMedium: TextStyle(
            fontSize: 16,
            color: Colors.purple[600],
          ),
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: const VoiceBMIPage(),
    );
  }
}

class VoiceBMIPage extends StatefulWidget {
  const VoiceBMIPage({super.key});

  @override
  VoiceBMIPageState createState() => VoiceBMIPageState();
}

class VoiceBMIPageState extends State<VoiceBMIPage>
    with SingleTickerProviderStateMixin {
  final Logger _logger = Logger(); // Inisialisasi Logger
  final stt.SpeechToText _speech = stt.SpeechToText();
  final Box<BMIRecord> _historyBox = Hive.box<BMIRecord>('bmiHistory');
  double? _weightKg;
  double? _heightCm;
  double? _bmi;
  bool _isSpeechAvailable = false;
  late AnimationController _animationController;
  bool _isEnglish = false;
  bool _isSelectMode = false;
  final Map<int, bool> _selectedItems = {};
  String _recognizedWords = '';
  Timer? _timeoutTimer;
  bool _showClassification = false;
  bool _autoCloseScheduled = false; // Added variable to track auto-close status

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true); // Animasi berulang
    _checkSpeechAvailability();
    _updateInitialText();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _timeoutTimer?.cancel();
    super.dispose();
  }

  void _updateInitialText() {
    setState(() {});
  }

  double get _weightDisplay => _weightKg != null
      ? (_isEnglish ? _weightKg! * 2.20462 : _weightKg!)
      : 0.0;
  double get _heightDisplay =>
      _heightCm != null ? (_isEnglish ? _heightCm! / 2.54 : _heightCm!) : 0.0;
  String get _weightUnit => _isEnglish ? 'lbs' : 'kg';
  String get _heightUnit => _isEnglish ? 'in' : 'cm';

  String _formatNumber(double value) {
    return _isEnglish
        ? value.toStringAsFixed(1)
        : value.toStringAsFixed(1).replaceAll('.', ',');
  }

  Future<bool> _checkConnectivity() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    return connectivityResult != ConnectivityResult.none;
  }

  Future<void> _checkSpeechAvailability() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _showError(_isEnglish
          ? 'Microphone permission required'
          : 'Izin mikrofon diperlukan');
      return;
    }

    final isConnected = await _checkConnectivity();
    if (!isConnected) {
      _showError(_isEnglish
          ? 'No internet connection. Speech recognition requires internet.'
          : 'Tidak ada koneksi internet. Pengenalan suara memerlukan internet.');
      return;
    }

    final isAvailable = await _speech.initialize(
      onStatus: (status) {
        if (mounted) {}
      },
      onError: (error) {
        String errorMessage;
        if (error.errorMsg.contains('network')) {
          errorMessage = _isEnglish
              ? 'Network error: Please check your internet connection.'
              : 'Kesalahan jaringan: Silakan periksa koneksi internet Anda.';
        } else {
          errorMessage =
              '${_isEnglish ? 'Error' : 'Kesalahan'}: ${error.errorMsg}';
        }
        _showError(errorMessage);
      },
    );

    if (mounted) {
      setState(() => _isSpeechAvailable = isAvailable);
    }
  }

  Future<void> _startListening() async {
    if (!_isSpeechAvailable) {
      _showError(_isEnglish
          ? 'Speech recognition not available. Please try again.'
          : 'Pengenalan suara tidak tersedia. Silakan coba lagi.');
      return;
    }

    final isConnected = await _checkConnectivity();
    if (!isConnected) {
      _showError(_isEnglish
          ? 'No internet connection. Speech recognition requires internet.'
          : 'Tidak ada koneksi internet. Pengenalan suara memerlukan internet.');
      return;
    }

    _recognizedWords = '';
    if (mounted) {
      setState(() {
        _heightCm = null;
        _weightKg = null;
        _bmi = null;
      });
    }

    _speech.listen(
      onResult: (result) {
        if (mounted) {
          setState(() {
            _recognizedWords = result.recognizedWords;
            _extractData(result.recognizedWords);
          });
        }
        if (result.finalResult) {
          _processSpeech(result.recognizedWords);
        }
      },
      listenFor: const Duration(seconds: 15),
      pauseFor: const Duration(seconds: 6),
      localeId: _isEnglish ? 'en_US' : 'id_ID',
      listenMode: stt.ListenMode.dictation,
    );

    if (mounted) {}
    _showListeningDialog();
  }

  void _processSpeech(String text) {
    if (_speech.isListening) return;
    if (mounted) {}
    _extractData(text);
    if (_weightKg == null || _heightCm == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isEnglish
                ? 'Incomplete data. Please try again.'
                : 'Data tidak lengkap. Silakan coba lagi.'),
          ),
        );
      }
    }
  }

  void _extractData(String text) {
    try {
      final regex = _isEnglish
          ? RegExp(
              r'(height|tall|weight|mass)?\s*(\d+[,.]?\d*)\s*(inches|in|lbs|pounds)?',
              caseSensitive: false,
            )
          : RegExp(
              r'(tinggi badan|tinggi|tb|berat|bb)?\s*(\d+[,.]?\d*)\s*(cm|sentimeter|kg|kilo)?',
              caseSensitive: false,
            );

      final matches = regex.allMatches(text).toList();

      double? height;
      double? weight;

      for (var match in matches) {
        final keyword = match.group(1)?.toLowerCase();
        final valueStr = match.group(2);
        final unit = match.group(3)?.toLowerCase();

        if (valueStr == null) continue;

        final value = double.parse(valueStr.replaceAll(',', '.'));

        if (unit == 'cm' ||
            unit == 'sentimeter' ||
            unit == 'inches' ||
            unit == 'in') {
          height = _isEnglish
              ? (unit == 'inches' || unit == 'in' ? value * 2.54 : value)
              : value;
        } else if (unit == 'kg' ||
            unit == 'kilo' ||
            unit == 'lbs' ||
            unit == 'pounds') {
          weight = _isEnglish
              ? (unit == 'lbs' || unit == 'pounds' ? value * 0.453592 : value)
              : value;
        } else if (keyword == 'tinggi' ||
            keyword == 'tinggi badan' ||
            keyword == 'tb' ||
            keyword == 'height' ||
            keyword == 'tall') {
          height = value;
        } else if (keyword == 'berat' ||
            keyword == 'bb' ||
            keyword == 'weight' ||
            keyword == 'mass') {
          weight = value;
        }
      }

      if (height != null || weight != null) {
        if (mounted) {
          setState(() {
            _heightCm = height ?? _heightCm;
            _weightKg = weight ?? _weightKg;
          });
        }
      }
    } catch (e) {
      _logger.e('Error ekstraksi: $e');
    }
  }

  void _calculateBMI() {
    if (_weightKg == null || _heightCm == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isEnglish
                ? 'Incomplete data. Please try again.'
                : 'Data tidak lengkap. Silakan coba lagi.'),
          ),
        );
      }
      return;
    }
    try {
      final heightInMeter = _heightCm! / 100;
      final bmi = _weightKg! / (heightInMeter * heightInMeter);
      if (mounted) {
        setState(() {
          _bmi = bmi;
        });
      }
    } catch (e) {
      _logger.e('Error saat menghitung BMI: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${_isEnglish ? 'Error' : 'Kesalahan'}: $e')),
        );
      }
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red[800],
          behavior: SnackBarBehavior.floating,
          action: SnackBarAction(
            label: _isEnglish ? 'Try Again' : 'Coba Lagi',
            textColor: Colors.white,
            onPressed: _startListening,
          ),
        ),
      );
  }

  void _toggleLanguage() {
    if (mounted) {
      setState(() {
        _isEnglish = !_isEnglish;
        _checkSpeechAvailability();
        _updateInitialText();
      });
    }
  }

  void _toggleSelectMode() {
    if (mounted) {
      setState(() {
        _isSelectMode = !_isSelectMode;
        _selectedItems.clear();
      });
    }
  }

  void _deleteSelected() {
    if (_selectedItems.isEmpty) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_isEnglish ? 'Delete Data?' : 'Hapus Data?'),
        content: Text(_isEnglish
            ? '${_selectedItems.length} data will be deleted'
            : '${_selectedItems.length} data akan dihapus'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(_isEnglish ? 'Cancel' : 'Batal'),
          ),
          TextButton(
            onPressed: () {
              final indices =
                  _selectedItems.keys.where((k) => _selectedItems[k]!).toList();
              _historyBox.deleteAll(indices);
              _toggleSelectMode();
              Navigator.pop(context);
            },
            child: Text(_isEnglish ? 'Delete' : 'Hapus',
                style: const TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_isEnglish ? 'About' : 'Tentang'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _isEnglish
                  ? 'This app is created by dr. Sapto Sutardi to calculate BMI (Body Mass Index), also known as Indeks Masa Tubuh (IMT) in Indonesia.'
                  : 'Aplikasi ini dibuat oleh dr. Sapto Sutardi untuk menghitung BMI (Body Mass Index) atau di Indonesia dikenal dengan Indeks Masa Tubuh (IMT).',
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 8),
            Text(
              _isEnglish
                  ? 'Purpose: A simple tool to monitor your weight status.'
                  : 'Tujuan: Alat sederhana untuk memantau status berat badan Anda, dengan IMT/BMI.',
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 8),
            Text(
              _isEnglish
                  ? 'Disclaimer: This app does not replace professional medical advice.'
                  : 'Pernyataan: Aplikasi ini tidak menggantikan pemeriksaan & rekomendasi medis profesional.',
              style: const TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(_isEnglish ? 'Close' : 'Tutup'),
          ),
        ],
      ),
    );
  }

  void _showListeningDialog() {
    BuildContext? dialogContext;

    _timeoutTimer?.cancel();
    _timeoutTimer = Timer(const Duration(seconds: 15), () {
      if (_speech.isListening) {
        _speech.stop();
      }
      if (mounted && dialogContext != null) {
        Navigator.of(dialogContext!, rootNavigator: true).pop();
        _calculateBMI();
      }
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        dialogContext = context;
        return AlertDialog(
          title: Text(_isEnglish
              ? 'Speak Weight and Height'
              : 'Ucapkan Berat dan Tinggi Badan'),
          content: AnimatedBuilder(
            animation: _animationController,
            builder: (context, child) {
              final pattern = _isEnglish
                  ? RegExp(
                      r'(height|tall|weight|mass)?\s*(\d+[,.]?\d*)\s*(inches|in|lbs|pounds)?',
                      caseSensitive: false,
                    )
                  : RegExp(
                      r'(tinggi badan|tinggi|tb|berat|bb)?\s*(\d+[,.]?\d*)\s*(cm|sentimeter|kg|kilo)?',
                      caseSensitive: false,
                    );

              final matches = pattern.allMatches(_recognizedWords).toList();

              List<TextSpan> textSpans = [];
              String remainingText = _recognizedWords;
              int lastEnd = 0;

              for (var match in matches) {
                final matchedText = match.group(0)!;
                final keyword = match.group(1)?.toLowerCase();
                final valueStr = match.group(2);
                final unit = match.group(3)?.toLowerCase();

                if (valueStr == null) continue;

                if (match.start > lastEnd) {
                  textSpans.add(
                    TextSpan(
                      text: remainingText.substring(lastEnd, match.start),
                    ),
                  );
                }

                bool isWeight = _isEnglish
                    ? (keyword == 'weight' ||
                        keyword == 'mass' ||
                        unit == 'lbs' ||
                        unit == 'pounds')
                    : (keyword == 'berat' ||
                        keyword == 'bb' ||
                        unit == 'kg' ||
                        unit == 'kilo');
                bool isHeight = _isEnglish
                    ? (keyword == 'height' ||
                        keyword == 'tall' ||
                        unit == 'inches' ||
                        unit == 'in')
                    : (keyword == 'tinggi' ||
                        keyword == 'tinggi badan' ||
                        keyword == 'tb' ||
                        unit == 'cm' ||
                        unit == 'sentimeter');

                textSpans.add(
                  TextSpan(
                    text: matchedText,
                    style: TextStyle(
                      backgroundColor:
                          (isWeight || isHeight) ? Colors.yellow : null,
                    ),
                  ),
                );

                lastEnd = match.end;
              }

              if (lastEnd < remainingText.length) {
                textSpans.add(
                  TextSpan(
                    text: remainingText.substring(lastEnd),
                  ),
                );
              }

              // Jika ikon check telah muncul, jadwalkan penutupan dialog otomatis 3 detik kemudian.
              if (_weightKg != null &&
                  _heightCm != null &&
                  !_autoCloseScheduled) {
                _autoCloseScheduled = true;
                Future.delayed(const Duration(seconds: 1), () {
                  if (Navigator.of(context).canPop()) {
                    Navigator.of(context).pop();
                  }
                });
              }

              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 100,
                    child: _weightKg != null && _heightCm != null
                        ? const Icon(
                            Icons.check_circle,
                            size: 100,
                            color: Colors.green,
                          )
                        : _buildMicSection(enableTap: false),
                  ),
                  const SizedBox(height: 16),
                  if (_weightKg == null || _heightCm == null)
                    Text(
                      _isEnglish ? 'Listening: ' : 'Mendengarkan: ',
                      style: const TextStyle(fontSize: 16),
                    ),
                  RichText(
                    text: TextSpan(
                      style: const TextStyle(fontSize: 16, color: Colors.black),
                      children: textSpans,
                    ),
                  ),
                ],
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () {
                _speech.stop();
                Navigator.pop(context);
                _calculateBMI();
              },
              child: Text(_isEnglish ? 'Done' : 'Selesai'),
            ),
          ],
        );
      },
    ).then((_) {
      _timeoutTimer?.cancel();
      _timeoutTimer = null;
      if (mounted) {
        _calculateBMI();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text(
              'BMI Voice',
              style: TextStyle(color: Colors.purple[900]),
            ),
            const SizedBox(width: 8),
            Text(
              'by dr. Sapto',
              style: GoogleFonts.kaushanScript(
                fontSize: 18,
                color: Colors.purple[900],
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, color: Colors.purple[900]),
            onSelected: (value) {
              if (value == 'history' && _historyBox.isNotEmpty)
                _toggleSelectMode();
              if (value == 'language') _toggleLanguage();
              if (value == 'about') _showAboutDialog();
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'history',
                child: Text(_isEnglish ? 'History' : 'Riwayat'),
              ),
              PopupMenuItem(
                value: 'language',
                child: Text(_isEnglish ? 'Change Language' : 'Ganti Bahasa'),
              ),
              PopupMenuItem(
                value: 'about',
                child: Text(_isEnglish ? 'About' : 'Tentang'),
              ),
            ],
          ),
        ],
      ),
      body: _isSelectMode
          ? _buildSelectableHistoryList()
          : SingleChildScrollView(
              child: Container(
                width: screenWidth * 0.9,
                margin:
                    const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withAlpha((0.3 * 255).toInt()),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding:
                          const EdgeInsets.only(left: 8, right: 8, bottom: 8),
                      child: Column(
                        children: [
                          _buildMicSection(enableTap: true),
                          _buildManualInputButton(),
                          const SizedBox(height: 6),
                          if (_weightKg != null && _heightCm != null)
                            _buildWeightCard(),
                        ],
                      ),
                    ),
                    if (_bmi != null) ...[
                      CustomPaint(
                        size: Size(screenWidth * 0.9, 4),
                        painter: TicketTearPainter(),
                      ),
                      Container(
                        padding: const EdgeInsets.only(
                            left: 8.0, right: 8.0, top: 2.0, bottom: 8.0),
                        child: Column(
                          children: [
                            _buildBMIGauge(),
                            const SizedBox(height: 8),
                            if (_showClassification)
                              _buildBMIClassificationTable(),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                FilledButton.icon(
                                  icon: const Icon(Icons.save),
                                  label: Text(_isEnglish ? 'Save' : 'Simpan'),
                                  onPressed:
                                      _saveBMI, // Tombol simpan diaktifkan
                                ),
                                IconButton(
                                  icon: Icon(
                                    _showClassification
                                        ? Icons.expand_less
                                        : Icons.expand_more,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      _showClassification =
                                          !_showClassification;
                                    });
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
      bottomNavigationBar: _isSelectMode ? _buildBulkActions() : null,
    );
  }

  // Fungsi untuk menyimpan BMI ke Hive box
  void _saveBMI() {
    if (_weightKg == null || _heightCm == null || _bmi == null) {
      _showError(_isEnglish
          ? 'Incomplete data to save.'
          : 'Data tidak lengkap untuk disimpan.');
      return;
    }
    final record = BMIRecord(_weightKg!, _heightCm!, _bmi!, DateTime.now());
    _historyBox.add(record);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isEnglish ? 'Data saved' : 'Data tersimpan'),
      ),
    );
  }

  Widget _buildSelectableHistoryList() {
    return ValueListenableBuilder(
      valueListenable: _historyBox.listenable(),
      builder: (context, Box<BMIRecord> box, _) {
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: box.length,
          itemBuilder: (context, index) {
            final record = box.getAt(index);
            return CheckboxListTile(
              value: _selectedItems[index] ?? false,
              onChanged: (value) => setState(() {
                _selectedItems[index] = value!;
              }),
              title: Text('BMI: ${_formatNumber(record!.bmi)}'),
              subtitle: Text(
                  '${_formatNumber(record.weight)} $_weightUnit, ${_formatNumber(record.height)} $_heightUnit'),
              secondary: Text(
                '${DateFormat('dd/MM/yy').format(record.timestamp)}\n${DateFormat('HH:mm').format(record.timestamp)}',
                textAlign: TextAlign.right,
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildWeightCard() {
    if (_weightKg == null || _heightCm == null) {
      return const SizedBox.shrink();
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color:
            (Colors.purple[50] ?? Colors.purple).withAlpha((0.8 * 255).toInt()),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        '${_formatNumber(_weightDisplay)} $_weightUnit | ${_formatNumber(_heightDisplay)} $_heightUnit',
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.purple[800],
        ),
      ),
    );
  }

  Widget _buildBMIClassificationTable() {
    return Card(
      elevation: 0, // Menghilangkan shadow
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8), // Border radius yang lembut
        side: BorderSide(
          color: Colors.grey[50]!, // Garis tepi untuk efek flat
          width: 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Table(
          columnWidths: const {
            0: FlexColumnWidth(2),
            1: FlexColumnWidth(1.5),
          },
          children: [
            TableRow(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16, right: 12, top: 2, bottom: 6),
                  child:
                      _buildTableHeader(_isEnglish ? 'Category' : 'Kategori'),
                ),
                _buildTableHeader('BMI'),
              ],
            ),
            ..._buildTableRows(),
          ],
        ),
      ),
    );
  }

  List<TableRow> _buildTableRows() {
    final List<Map<String, dynamic>> categories = [
      {
        'categoryId': 'BB Kurang',
        'categoryEn': 'Underweight',
        'rangeId': '< 18,5',
        'rangeEn': '< 18.5',
        'color': Colors.blue,
      },
      {
        'categoryId': 'Normal',
        'categoryEn': 'Normal',
        'rangeId': '18,5 - 22,9',
        'rangeEn': '18.5 - 22.9',
        'color': Colors.green,
      },
      {
        'categoryId': 'BB lebih dgn Risiko',
        'categoryEn': 'Overweight at Risk',
        'rangeId': '23 - 24,9',
        'rangeEn': '23 - 24.9',
        'color': Colors.orange,
      },
      {
        'categoryId': 'Obesitas I',
        'categoryEn': 'Obese I',
        'rangeId': '25 - 29,9',
        'rangeEn': '25 - 29.9',
        'color': Colors.deepOrange,
      },
      {
        'categoryId': 'Obesitas II',
        'categoryEn': 'Obese II',
        'rangeId': '≥ 30',
        'rangeEn': '≥ 30',
        'color': Colors.red,
      },
    ];

    return categories.map((cat) {
      final isCurrentCategory = _isCategoryMatch(
        _isEnglish ? cat['rangeEn'] as String : cat['rangeId'] as String,
      );
      _logger.d('--> isCurrentCategory: $isCurrentCategory');
      return _buildTableRow(
        _isEnglish ? cat['categoryEn'] as String : cat['categoryId'] as String,
        _isEnglish ? cat['rangeEn'] as String : cat['rangeId'] as String,
        cat['color'] as Color,
        isCurrentCategory,
      );
    }).toList();
  }

  bool _isCategoryMatch(String range) {
    if (_bmi == null) return false;

    // Bersihkan simbol dan whitespace
    final cleanedRange = range.replaceAll(RegExp(r'[<≥]'), '').trim();
    final rangeParts = cleanedRange.split(' - ');

    // Parse bagian numerik
    final minValue = _parseNumber(rangeParts[0]);
    final maxValue = rangeParts.length > 1 ? _parseNumber(rangeParts[1]) : null;

    // Handle range khusus
    if (range.contains('<')) {
      return _bmi! < minValue!;
    } else if (range.contains('≥')) {
      return _bmi! >= minValue!;
    } else if (maxValue != null) {
      return _bmi! >= minValue! && _bmi! < maxValue;
    }

    return false;
  }

  TableRow _buildTableRow(
      String category, String range, Color color, bool isCurrent) {
    return TableRow(
      decoration: isCurrent
          ? BoxDecoration(
              color: color.withAlpha(50), // Transparansi warna
              borderRadius: BorderRadius.circular(8),
            )
          : null,
      children: [
        Padding(
          padding: const EdgeInsets.only(
              left: 16.0, top: 4, bottom: 4), // Padding kiri
          child: Text(
            category,
            style: TextStyle(
              fontSize: 10,
              fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
          child: Text(
            range,
            style: TextStyle(
              fontSize: 10,
              fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTableHeader(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Text(
        text,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.purple,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildMicSection({required bool enableTap}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Center(
        child: GestureDetector(
          onTap: enableTap && _isSpeechAvailable ? _startListening : null,
          child: AnimatedBuilder(
            animation: _animationController,
            builder: (context, child) {
              return SizedBox(
                width: 100,
                height: 100,
                child: SiriLogoWidgetV2(
                  animationValue: _animationController.value,
                  isActive: enableTap, // Meneruskan parameter ke child widget
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildManualInputButton() {
    return FilledButton.icon(
      icon: const Icon(Icons.keyboard),
      label: Text(_isEnglish ? 'Manual Input' : 'Input Manual'),
      onPressed: _showManualInputDialog,
    );
  }

  void _showManualInputDialog() {
    final weightController = TextEditingController();
    final heightController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_isEnglish ? 'Manual Input' : 'Input Manual'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: weightController,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$')),
                LengthLimitingTextInputFormatter(5), // Maksimal 5 karakter
              ],
              decoration: InputDecoration(
                labelText: '${_isEnglish ? 'Weight' : 'Berat'} ($_weightUnit)',
                icon: const Icon(Icons.scale),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: heightController,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*$')),
                LengthLimitingTextInputFormatter(5), // Maksimal 5 karakter
              ],
              decoration: InputDecoration(
                labelText: '${_isEnglish ? 'Height' : 'Tinggi'} ($_heightUnit)',
                icon: const Icon(Icons.straighten),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(_isEnglish ? 'Cancel' : 'Batal'),
          ),
          FilledButton(
            onPressed: () => _handleManualInput(
                weightController.text, heightController.text, context),
            child: Text(_isEnglish ? 'Calculate' : 'Hitung'),
          ),
        ],
      ),
    );
  }

  void _handleManualInput(String weight, String height, BuildContext context) {
    if (weight.isEmpty || height.isEmpty) {
      _showError(_isEnglish ? 'Fill all fields' : 'Isi semua kolom');
      return;
    }

    final parsedWeight = _parseNumber(weight);
    final parsedHeight = _parseNumber(height);

    if (parsedWeight == null || parsedHeight == null) {
      _showError(_isEnglish ? 'Invalid number' : 'Angka tidak valid');
      return;
    }

    setState(() {
      _weightKg = _isEnglish ? parsedWeight / 2.20462 : parsedWeight;
      _heightCm = _isEnglish ? parsedHeight * 2.54 : parsedHeight;
    });

    Navigator.pop(context);
    _calculateBMI();
  }

  double? _parseNumber(String value) {
    // Handle koma sebagai desimal
    final cleanedValue =
        value.replaceAll(',', '.').replaceAll(RegExp(r'[^0-9.]'), '');
    return double.tryParse(cleanedValue);
  }

  Widget _buildBMIGauge() {
    if (_bmi == null || _heightCm == null || _weightKg == null) {
      return Text(_isEnglish ? 'Waiting for data...' : 'Menunggu data...');
    }

    final screenWidth = MediaQuery.of(context).size.width;
    final double gaugeWidth = screenWidth * 0.8;
    final double segmentWidth = gaugeWidth / 5;

    double arrowPosition;
    _logger.i('BMI: $_bmi');
    if (_bmi! < 18.5) {
      _logger.d('Segmen 1');
      final double minPosition = gaugeWidth * 0.05; // 5% margin kiri
      double calculatedPositionUnderweight = (_bmi! / 18.5) * segmentWidth;
      arrowPosition = math.max(calculatedPositionUnderweight, minPosition);
    } else if (_bmi! < 23) {
      _logger.d('Segmen 2');
      arrowPosition =
          segmentWidth + ((_bmi! - 18.5) / (22.9 - 18.5)) * segmentWidth;
    } else if (_bmi! < 25) {
      _logger.d('Segmen 3');
      arrowPosition =
          2 * segmentWidth + ((_bmi! - 23) / (24.9 - 23)) * segmentWidth;
    } else if (_bmi! < 30) {
      _logger.d('Segmen 4');
      arrowPosition =
          3 * segmentWidth + ((_bmi! - 25) / (29.9 - 25)) * segmentWidth;
    } else {
      _logger.d('Segmen 5');
      const double marginRight = 0.05; // 5% margin kanan
      final double maxAllowedWidth = gaugeWidth * (1 - marginRight);
      final double basePosition = 4 * segmentWidth; // Posisi awal segmen 5
      final double extension = ((_bmi! - 30) / 20) *
          segmentWidth; // Setiap 20 BMI tambahan mengisi 1 segmen
      arrowPosition = math.min(basePosition + extension, maxAllowedWidth);
    }
    _logger.i('Arrow Position: $arrowPosition');

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 4),
      child: Column(
        children: [
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch, // Gunakan stretch
              children: [
                Expanded(
                  child: Container(
                    width: screenWidth * 0.4,
                    padding: const EdgeInsets.symmetric(
                        vertical: 8), // Tambahkan padding vertikal
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment
                          .spaceEvenly, // Distribusi ruang merata
                      mainAxisSize: MainAxisSize.max, // Isi tinggi maksimal
                      children: [
                        Text(
                          'BMI',
                          style:
                              Theme.of(context).textTheme.titleLarge!.copyWith(
                                    fontSize: 16,
                                    fontWeight: FontWeight.normal,
                                  ),
                        ),
                        Text(
                          _formatNumber(_bmi!),
                          style:
                              Theme.of(context).textTheme.titleLarge!.copyWith(
                                    fontSize: 48,
                                    fontWeight: FontWeight.bold,
                                  ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    width: screenWidth * 0.4,
                    padding: const EdgeInsets.symmetric(
                        vertical: 8), // Padding konsisten
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Flexible(
                          child: Text(
                            _getBMICategory(),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: _getBMIColor(),
                            ),
                          ),
                        ),
                        Flexible(
                          child: Text(
                            _getWeightStatus(),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Flexible(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.purple[50]!
                                  .withAlpha((0.8 * 255).toInt()),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Center(
                              child: Text(
                                '${_isEnglish ? 'Ideal wt.' : 'BB Ideal'}: ${_formatNumber(_getIdealMinKg())}-${_formatNumber(_getIdealMaxKg())} $_weightUnit',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Column(
            children: [
              Stack(
                alignment: Alignment.center,
                clipBehavior: Clip.none,
                children: [
                  SizedBox(
                    height: 24,
                    width: gaugeWidth,
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(12),
                                bottomLeft: Radius.circular(12),
                              ),
                            ),
                            child: Center(
                              child: Text(
                                _isEnglish ? '< 18.5' : '< 18,5',
                                style: const TextStyle(
                                  fontSize: 8,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: Colors.green,
                            child: Center(
                              child: Text(
                                _isEnglish ? '18.5 - 22.9' : '18,5 - 22,9',
                                style: const TextStyle(
                                  fontSize: 8,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: Colors.orange,
                            child: Center(
                              child: Text(
                                _isEnglish ? '23 - 24.9' : '23 - 24,9',
                                style: const TextStyle(
                                  fontSize: 8,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: Colors.deepOrange,
                            child: Center(
                              child: Text(
                                _isEnglish ? '25 - 29.9' : '25 - 29,9',
                                style: const TextStyle(
                                  fontSize: 8,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Colors.red,
                              borderRadius: BorderRadius.only(
                                topRight: Radius.circular(12),
                                bottomRight: Radius.circular(12),
                              ),
                            ),
                            child: Center(
                              child: Text(
                                '≥ 30',
                                style: const TextStyle(
                                  fontSize: 8,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    left: arrowPosition - 12,
                    top: -30,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Transform.translate(
                          offset: const Offset(0, 6),
                          child: Text(
                            _formatNumber(_bmi!),
                            style: const TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const Icon(
                          Icons.arrow_drop_down,
                          size: 24,
                          color: Colors.black,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Container(
                width: gaugeWidth,
                margin: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(
                  children: [
                    Expanded(
                      child: _buildCategoryLabel(
                        _isEnglish ? 'Under' : 'Kurang',
                        Colors.blue,
                        isCurrent: _bmi != null && _bmi! < 18.5,
                      ),
                    ),
                    Expanded(
                      child: _buildCategoryLabel(
                        _isEnglish ? 'Normal' : 'Normal',
                        Colors.green,
                        isCurrent: _bmi != null && _bmi! >= 18.5 && _bmi! < 23,
                      ),
                    ),
                    Expanded(
                      child: _buildCategoryLabel(
                        _isEnglish ? 'Over' : 'Lebih',
                        Colors.orange,
                        isCurrent: _bmi != null && _bmi! >= 23 && _bmi! < 25,
                      ),
                    ),
                    Expanded(
                      child: _buildCategoryLabel(
                        _isEnglish ? 'Obese I' : 'Obes I',
                        Colors.deepOrange,
                        isCurrent: _bmi != null && _bmi! >= 25 && _bmi! < 30,
                      ),
                    ),
                    Expanded(
                      child: _buildCategoryLabel(
                        _isEnglish ? 'Obese II' : 'Obes II',
                        Colors.red,
                        isCurrent: _bmi != null && _bmi! >= 30,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryLabel(String title, Color color,
      {bool isCurrent = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: 4, vertical: 2), // Padding diperkecil
      decoration: isCurrent
          ? BoxDecoration(
              color: color.withAlpha(50), // Transparansi warna
              borderRadius: BorderRadius.circular(4),
            )
          : null,
      child: Text(
        title,
        textAlign: TextAlign.center,
        softWrap: true, // Memungkinkan text wrapping
        style: TextStyle(
          fontSize: 10,
          fontWeight: isCurrent
              ? FontWeight.bold
              : FontWeight.normal, // Bold hanya untuk BMI saat ini
        ),
      ),
    );
  }

  String _getWeightStatus() {
    if (_heightCm == null || _weightKg == null) {
      return _isEnglish ? 'Data incomplete' : 'Data belum lengkap';
    }
    final heightM = _heightCm! / 100;
    final idealMinKg = 18.5 * heightM * heightM;
    final idealMaxKg = 22.9 * heightM * heightM;
    final currentWeight = _weightKg!;

    if (currentWeight < idealMinKg) {
      return _isEnglish
          ? 'Need +${_formatNumber(idealMinKg - currentWeight)} $_weightUnit'
          : 'Perlu +${_formatNumber(idealMinKg - currentWeight)} $_weightUnit';
    } else if (currentWeight > idealMaxKg) {
      return _isEnglish
          ? 'Need -${_formatNumber(currentWeight - idealMaxKg)} $_weightUnit'
          : 'Perlu -${_formatNumber(currentWeight - idealMaxKg)} $_weightUnit';
    } else {
      return _isEnglish ? 'Ideal!' : 'Ideal!';
    }
  }

  double _getIdealMinKg() {
    if (_heightCm == null) return 0;
    final heightM = _heightCm! / 100;
    return 18.5 * heightM * heightM;
  }

  double _getIdealMaxKg() {
    if (_heightCm == null) return 0;
    final heightM = _heightCm! / 100;
    return 22.9 * heightM * heightM;
  }

  String _getBMICategory() {
    if (_bmi! < 18.5) return _isEnglish ? 'Underweight' : 'BB Kurang';
    if (_bmi! < 23) return _isEnglish ? 'Normal Weight' : 'BB Normal';
    if (_bmi! < 25) {
      return _isEnglish ? 'Overweight with Risk' : 'BB lebih dgn Risiko';
    }
    if (_bmi! < 30) return _isEnglish ? 'Obesity I' : 'Obesitas I';
    return _isEnglish ? 'Obesity II' : 'Obesitas II';
  }

  Color _getBMIColor() {
    if (_bmi! < 18.5) return Colors.blue;
    if (_bmi! < 23) return Colors.green;
    if (_bmi! < 25) return Colors.orange;
    if (_bmi! < 30) return Colors.deepOrange;
    return Colors.red;
  }

  Widget _buildBulkActions() {
    return Container(
      color: Colors.purple[50],
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Checkbox(
                value: _selectedItems.length == _historyBox.length,
                onChanged: (v) => setState(() {
                  if (v!) {
                    for (int i = 0; i < _historyBox.length; i++) {
                      _selectedItems[i] = true;
                    }
                  } else {
                    _selectedItems.clear();
                  }
                }),
              ),
              Text(_isEnglish ? 'Select All' : 'Pilih Semua'),
            ],
          ),
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: _deleteSelected,
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: _toggleSelectMode,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class TicketTearPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final backgroundPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      backgroundPaint,
    );

    final linePaint = Paint()
      ..color = Colors.grey.withAlpha((0.6 * 255).toInt())
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round;

    const dashWidth = 6.0;
    const dashSpace = 4.0;
    double startX = 10;
    double endX = size.width - 10;

    while (startX < endX) {
      canvas.drawLine(
        Offset(startX, size.height / 2),
        Offset(startX + dashWidth, size.height / 2),
        linePaint,
      );
      startX += dashWidth + dashSpace;
    }

    final notchPaint = Paint()
      ..color = Colors.grey[300]!
      ..style = PaintingStyle.fill;

    final shadowPaint = Paint()
      ..color = Colors.grey.withAlpha((0.1 * 255).toInt())
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.0);

    canvas.drawCircle(
      Offset(0, size.height / 2 + 2),
      10,
      shadowPaint,
    );
    canvas.drawArc(
      Rect.fromCircle(center: Offset(0, size.height / 2), radius: 10),
      -3.14 / 2,
      3.14,
      true,
      notchPaint,
    );

    canvas.drawCircle(
      Offset(size.width, size.height / 2 - 2),
      10,
      shadowPaint,
    );
    canvas.drawArc(
      Rect.fromCircle(center: Offset(size.width, size.height / 2), radius: 10),
      3.14 / 2,
      3.14,
      true,
      notchPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class SiriLogoWidgetV2 extends StatelessWidget {
  final double animationValue;

  const SiriLogoWidgetV2(
      {super.key, required this.animationValue, required bool isActive});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Tentukan outerDiameter berdasarkan ruang yang tersedia
        final outerDiameter = constraints.maxWidth < constraints.maxHeight
            ? constraints.maxWidth
            : constraints.maxHeight;
        final innerDiameter = outerDiameter * 0.75; // Diameter lingkaran dalam

        return Center(
          child: SizedBox(
            width: outerDiameter,
            height: outerDiameter,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Canvas custom painting dengan animasi gradien dan gelombang suara
                CustomPaint(
                  size: Size(outerDiameter, outerDiameter),
                  painter: SiriLogoPainter2(animationValue),
                ),
                // Lingkaran dalam dengan ikon mikrofon
                Container(
                  width: innerDiameter,
                  height: innerDiameter,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white, // Latar belakang putih
                  ),
                  child: Center(
                    child: ShaderMask(
                      shaderCallback: (bounds) {
                        return LinearGradient(
                          colors: [Colors.deepPurple, Colors.purpleAccent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ).createShader(bounds);
                      },
                      child: const Icon(
                        Icons.mic,
                        size: 36,
                        color: Colors
                            .white, // Warna ikon akan diganti dengan gradient
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class SiriLogoWidget extends StatelessWidget {
  final double animationValue;

  const SiriLogoWidget({super.key, required this.animationValue});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Tentukan outerDiameter berdasarkan ruang yang tersedia
        final outerDiameter = constraints.maxWidth < constraints.maxHeight
            ? constraints.maxWidth
            : constraints.maxHeight;
        // Diameter overlay 80% dari outerDiameter
        final innerDiameter = outerDiameter * 0.8;

        return Center(
          child: SizedBox(
            width: outerDiameter,
            height: outerDiameter,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Lingkaran luar dengan animasi skala
                Transform.scale(
                  scale: 0.8 + 0.2 * (1 - (2 * animationValue - 1).abs()),
                  child: CustomPaint(
                    size: Size(outerDiameter, outerDiameter),
                    painter: SiriLogoPainter2(animationValue),
                  ),
                ),
                // Lingkaran dalam dengan ikon mikrofon (tetap statis)
                Container(
                  width: innerDiameter,
                  height: innerDiameter,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.mic,
                      size: 36,
                      color: Colors.deepPurple,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class SiriLogoPainter2 extends CustomPainter {
  final double animationValue;

  SiriLogoPainter2(this.animationValue);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2;
    final currentRadius = maxRadius * (0.8 + 0.2 * animationValue);

    final gradient = SweepGradient(
      colors: const [
        Colors.purpleAccent,
        Colors.blueAccent,
        Colors.cyanAccent,
        Colors.greenAccent,
        Colors.purpleAccent,
      ],
      stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
      transform: GradientRotation(animationValue * 3.1416 * 2),
    ).createShader(Rect.fromCircle(center: center, radius: currentRadius));

    final paint = Paint()
      ..shader = gradient
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, currentRadius, paint);
  }

  @override
  bool shouldRepaint(covariant SiriLogoPainter2 oldDelegate) =>
      oldDelegate.animationValue != animationValue;
}

@HiveType(typeId: 0)
class BMIRecord extends HiveObject {
  @HiveField(0)
  final double weight;
  @HiveField(1)
  final double height;
  @HiveField(2)
  final double bmi;
  @HiveField(3)
  final DateTime timestamp;

  BMIRecord(this.weight, this.height, this.bmi, this.timestamp);
}

class BMIRecordAdapter extends TypeAdapter<BMIRecord> {
  @override
  final int typeId = 0;

  @override
  BMIRecord read(BinaryReader reader) {
    return BMIRecord(
      reader.readDouble(),
      reader.readDouble(),
      reader.readDouble(),
      reader.read(),
    );
  }

  @override
  void write(BinaryWriter writer, BMIRecord obj) {
    writer.writeDouble(obj.weight);
    writer.writeDouble(obj.height);
    writer.writeDouble(obj.bmi);
    writer.write(obj.timestamp);
  }
}
