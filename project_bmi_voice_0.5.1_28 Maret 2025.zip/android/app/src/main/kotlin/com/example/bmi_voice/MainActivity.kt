package com.example.bmi_voice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
